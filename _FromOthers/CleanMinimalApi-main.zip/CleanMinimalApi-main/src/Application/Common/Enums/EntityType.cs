namespace CleanMinimalApi.Application.Common.Enums;

public enum EntityType
{
    Author,
    Movie,
    Review
}
