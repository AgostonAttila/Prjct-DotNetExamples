namespace CleanMinimalApi.Application.Authors.Entities;

public record ReviewAuthor(Guid Id, string FirstName, string LastName);
