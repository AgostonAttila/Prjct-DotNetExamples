namespace CleanMinimalApi.Application.Movies.Entities;

public record ReviewedMovie(Guid Id, string Title);
