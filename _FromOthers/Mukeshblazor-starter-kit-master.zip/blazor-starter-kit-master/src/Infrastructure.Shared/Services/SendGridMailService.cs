﻿namespace BlazorHero.CleanArchitecture.Infrastructure.Shared.Services
{
    internal class SendGridMailService
    {
    }
}