﻿namespace BlazorHero.CleanArchitecture.Application.Interfaces.Common
{
    public interface IScopedService
    {
    }
}