﻿namespace BlazorHero.CleanArchitecture.Application.Interfaces.Repositories
{
    public interface IBrandRepository
    {
    }
}