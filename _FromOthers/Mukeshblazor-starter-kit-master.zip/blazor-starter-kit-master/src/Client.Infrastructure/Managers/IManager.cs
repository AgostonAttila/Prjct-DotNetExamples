﻿namespace BlazorHero.CleanArchitecture.Client.Infrastructure.Managers
{
    public interface IManager
    {
    }
}