﻿namespace BlazorHero.CleanArchitecture.Client.Infrastructure.Routes
{
    public class DashboardEndpoints
    {
        public static string GetData = "api/v1/dashboard";
    }
}