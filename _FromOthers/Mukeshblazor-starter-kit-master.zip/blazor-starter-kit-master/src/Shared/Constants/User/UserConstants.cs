﻿namespace BlazorHero.CleanArchitecture.Shared.Constants.User
{
    public static class UserConstants
    {
        public const string DefaultPassword = "123Pa$$word!";
    }
}