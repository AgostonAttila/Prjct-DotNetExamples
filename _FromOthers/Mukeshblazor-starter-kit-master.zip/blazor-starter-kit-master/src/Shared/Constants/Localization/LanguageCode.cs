﻿namespace BlazorHero.CleanArchitecture.Shared.Constants.Localization
{
    public class LanguageCode
    {
        public string DisplayName { get; set; }
        public string Code { get; set; }
    }
}
