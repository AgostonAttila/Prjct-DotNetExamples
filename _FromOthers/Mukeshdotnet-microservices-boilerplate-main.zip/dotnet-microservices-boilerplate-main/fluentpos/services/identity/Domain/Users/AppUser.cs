﻿using Microsoft.AspNetCore.Identity;

namespace FluentPos.Identity.Domain.Users;
public class AppUser : IdentityUser { }