﻿namespace FluentPos.Identity.Application;
public class IdentityCore
{
}
