﻿namespace FluentPos.Catalog.Application;
public static class CatalogApplication
{
}
