﻿namespace FluentPos.Cart.Application.Features;
internal class DeleteCart
{
}
