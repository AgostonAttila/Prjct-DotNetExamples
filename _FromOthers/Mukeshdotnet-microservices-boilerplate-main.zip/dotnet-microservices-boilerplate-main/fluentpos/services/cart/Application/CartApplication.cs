﻿namespace FluentPos.Cart.Application;

public class CartApplication
{
}
