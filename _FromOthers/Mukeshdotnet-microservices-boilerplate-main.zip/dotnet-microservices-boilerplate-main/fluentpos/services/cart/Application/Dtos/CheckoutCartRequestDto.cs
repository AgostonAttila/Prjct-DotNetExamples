﻿namespace FluentPos.Cart.Application.Dtos;
public class CheckoutCartRequestDto
{
    public string? CreditCardNumber { get; set; }
}
