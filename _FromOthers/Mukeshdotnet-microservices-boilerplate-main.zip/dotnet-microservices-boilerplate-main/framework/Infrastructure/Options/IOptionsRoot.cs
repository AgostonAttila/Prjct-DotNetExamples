﻿namespace FSH.Framework.Infrastructure.Options;

public interface IOptionsRoot
{
}
