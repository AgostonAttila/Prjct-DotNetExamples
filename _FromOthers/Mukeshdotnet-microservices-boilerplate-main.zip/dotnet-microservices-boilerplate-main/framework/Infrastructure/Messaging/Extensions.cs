﻿namespace FSH.Framework.Infrastructure.Messaging
{
    internal class Extensions
    {
    }
}
