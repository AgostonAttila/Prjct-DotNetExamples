﻿using FluentValidation;

namespace FSH.Framework.Core.Validation;
public class CustomValidator<T> : AbstractValidator<T>
{
}