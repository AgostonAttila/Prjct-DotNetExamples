﻿namespace FSH.Framework.Core.Events;
public interface IIntegrationEvent : IEvent
{
}
