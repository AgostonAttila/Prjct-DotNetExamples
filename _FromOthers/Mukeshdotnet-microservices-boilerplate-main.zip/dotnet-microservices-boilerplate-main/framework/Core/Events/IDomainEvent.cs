﻿namespace FSH.Framework.Core.Events;
public interface IDomainEvent : IEvent
{
}
