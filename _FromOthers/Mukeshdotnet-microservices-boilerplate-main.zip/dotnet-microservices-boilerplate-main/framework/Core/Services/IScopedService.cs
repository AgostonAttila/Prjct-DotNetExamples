﻿namespace FSH.Framework.Core.Services;

public interface IScopedService
{
}
