namespace MinimalApiCleanArchitecture.Domain.Entities;

public class BaseEntity
{
    public Guid  Id { get; set; }
}