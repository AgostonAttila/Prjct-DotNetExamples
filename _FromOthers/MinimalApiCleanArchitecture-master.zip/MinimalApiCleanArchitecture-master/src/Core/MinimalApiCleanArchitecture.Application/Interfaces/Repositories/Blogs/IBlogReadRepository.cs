using MinimalApiCleanArchitecture.Domain.Model;

namespace MinimalApiCleanArchitecture.Application.Interfaces.Repositories.Blogs;

public interface IBlogReadRepository: IGenericReadRepository<Blog>
{
    
}