﻿namespace MinimalApiCleanArchitecture.Application.Features.AuthorFeature.Commands.DeleteAuthor;

public class DeleteAuthorResponse
{
    public bool Status { get; set; }
}