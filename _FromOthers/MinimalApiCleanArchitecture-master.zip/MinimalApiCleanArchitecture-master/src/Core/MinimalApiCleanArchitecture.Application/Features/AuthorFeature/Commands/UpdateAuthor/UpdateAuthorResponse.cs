﻿namespace MinimalApiCleanArchitecture.Application.Features.AuthorFeature.Commands.UpdateAuthor;

public class UpdateAuthorResponse
{
    public bool Status { get; set; } 
}