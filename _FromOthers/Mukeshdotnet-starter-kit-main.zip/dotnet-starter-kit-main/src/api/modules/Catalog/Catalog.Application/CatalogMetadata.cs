﻿namespace FSH.Starter.WebApi.Catalog.Application;
public static class CatalogMetadata
{
    public static string Name { get; set; } = "CatalogApplication";
}

