﻿namespace FSH.Starter.WebApi.Catalog.Application.Products.Create.v1;
public sealed record CreateProductResponse(Guid? Id);
