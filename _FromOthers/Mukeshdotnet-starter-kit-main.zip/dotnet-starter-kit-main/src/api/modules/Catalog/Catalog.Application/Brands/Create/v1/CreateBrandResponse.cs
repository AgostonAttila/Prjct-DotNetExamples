﻿namespace FSH.Starter.WebApi.Catalog.Application.Brands.Create.v1;

public sealed record CreateBrandResponse(Guid? Id);

