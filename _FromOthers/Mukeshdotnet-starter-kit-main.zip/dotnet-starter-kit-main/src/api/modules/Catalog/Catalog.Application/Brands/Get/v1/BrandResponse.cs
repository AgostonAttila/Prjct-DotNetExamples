namespace FSH.Starter.WebApi.Catalog.Application.Brands.Get.v1;
public sealed record BrandResponse(Guid? Id, string Name, string? Description);
