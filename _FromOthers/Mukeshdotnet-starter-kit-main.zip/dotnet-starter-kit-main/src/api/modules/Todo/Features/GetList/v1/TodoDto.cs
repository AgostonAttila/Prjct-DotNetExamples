﻿namespace FSH.Starter.WebApi.Todo.Features.GetList.v1;
public record TodoDto(Guid? Id, string Title, string Note);
