﻿namespace FSH.Starter.WebApi.Todo.Features.Create.v1;
public record CreateTodoResponse(Guid? Id);
