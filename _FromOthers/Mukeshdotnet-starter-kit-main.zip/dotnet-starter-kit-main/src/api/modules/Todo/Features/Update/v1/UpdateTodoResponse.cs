﻿namespace FSH.Starter.WebApi.Todo.Features.Update.v1;
public record UpdateTodoResponse(Guid? Id);

