﻿namespace FSH.Starter.WebApi.Todo.Features.Get.v1;
public record GetTodoResponse(Guid? Id, string? Title, string? Note);
