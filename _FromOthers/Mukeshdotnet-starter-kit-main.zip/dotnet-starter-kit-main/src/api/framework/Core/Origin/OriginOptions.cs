﻿namespace FSH.Framework.Core.Origin;

public class OriginOptions
{
    public Uri? OriginUrl { get; set; }
}
