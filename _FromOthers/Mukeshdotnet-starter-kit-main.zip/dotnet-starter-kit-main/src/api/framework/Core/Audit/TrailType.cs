﻿namespace FSH.Framework.Core.Audit;
public enum TrailType
{
    None = 0,
    Create = 1,
    Update = 2,
    Delete = 3
}
