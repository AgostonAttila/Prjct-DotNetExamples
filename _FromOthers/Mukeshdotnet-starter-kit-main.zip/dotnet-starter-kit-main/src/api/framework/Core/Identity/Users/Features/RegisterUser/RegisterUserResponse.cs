﻿namespace FSH.Framework.Core.Identity.Users.Features.RegisterUser;
public record RegisterUserResponse(string UserId);
