﻿namespace FSH.Framework.Core.Identity.Users.Features.ForgotPassword;
public class ForgotPasswordCommand
{
    public string Email { get; set; } = default!;
}
