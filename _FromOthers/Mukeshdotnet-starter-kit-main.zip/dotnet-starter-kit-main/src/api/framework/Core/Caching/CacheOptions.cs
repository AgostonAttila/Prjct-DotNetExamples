namespace FSH.Framework.Core.Caching;

public class CacheOptions
{
    public string Redis { get; set; } = string.Empty;
}
