﻿namespace FSH.Framework.Core.Tenant.Features.ActivateTenant;
public record ActivateTenantResponse(string Status);
