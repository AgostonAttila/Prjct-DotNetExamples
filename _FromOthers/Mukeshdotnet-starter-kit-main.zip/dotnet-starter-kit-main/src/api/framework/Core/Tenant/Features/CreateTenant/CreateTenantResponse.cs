﻿namespace FSH.Framework.Core.Tenant.Features.CreateTenant;
public record CreateTenantResponse(string Id);
