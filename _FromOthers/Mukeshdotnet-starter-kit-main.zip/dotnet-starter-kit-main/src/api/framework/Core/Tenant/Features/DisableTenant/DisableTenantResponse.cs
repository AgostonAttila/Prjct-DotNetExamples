﻿namespace FSH.Framework.Core.Tenant.Features.DisableTenant;
public record DisableTenantResponse(string Status);
