﻿namespace FSH.Framework.Core;
public static class FshCore
{
    public static string Name { get; set; } = "FshCore";
}
