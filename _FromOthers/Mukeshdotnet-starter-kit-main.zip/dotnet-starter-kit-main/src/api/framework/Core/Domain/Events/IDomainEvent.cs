﻿namespace FSH.Framework.Core.Domain.Events;
public interface IDomainEvent
{
}
