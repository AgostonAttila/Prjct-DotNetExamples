﻿using System.ComponentModel;

namespace FSH.Framework.Core.Storage.File;

public enum FileType
{
    [Description(".jpg,.png,.jpeg")]
    Image
}
