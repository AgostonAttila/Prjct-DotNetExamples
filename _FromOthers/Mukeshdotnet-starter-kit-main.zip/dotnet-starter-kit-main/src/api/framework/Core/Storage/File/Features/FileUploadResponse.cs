﻿namespace FSH.Framework.Core.Storage.File.Features;

public class FileUploadResponse
{
    public Uri Url { get; set; } = default!;
}

