﻿namespace FSH.Framework.Infrastructure;
public class FshInfrastructure
{
    public static string Name { get; set; } = "FshInfrastructure";
}
