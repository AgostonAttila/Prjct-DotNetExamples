﻿using Microsoft.AspNetCore.Authorization;

namespace FSH.Framework.Infrastructure.Auth.Policy;
public class PermissionAuthorizationRequirement : IAuthorizationRequirement;
