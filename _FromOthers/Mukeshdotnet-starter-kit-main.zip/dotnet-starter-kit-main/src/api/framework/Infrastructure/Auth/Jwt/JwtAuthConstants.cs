﻿namespace FSH.Framework.Infrastructure.Auth.Jwt;
internal static class JwtAuthConstants
{
    public const string Issuer = "https://fullstackhero.net";
    public const string Audience = "fullstackhero";
}
