﻿namespace FSH.Framework.Infrastructure.Constants;
public static class QueryStringKeys
{
    public const string Code = "code";
    public const string UserId = "userId";
}
