﻿namespace FSH.Framework.Infrastructure.Persistence;
internal static class DbProviders
{
    public const string PostgreSQL = "POSTGRESQL";
    public const string MSSQL = "MSSQL";
}
