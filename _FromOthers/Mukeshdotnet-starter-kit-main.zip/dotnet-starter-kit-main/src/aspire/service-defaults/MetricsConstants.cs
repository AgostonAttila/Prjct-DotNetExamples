﻿namespace FSH.Starter.Aspire.ServiceDefaults;
public static class MetricsConstants
{
    public const string AppName = "fullstackhero";
    public const string Todos = "Todos";
    public const string Catalog = "Catalog";
}
