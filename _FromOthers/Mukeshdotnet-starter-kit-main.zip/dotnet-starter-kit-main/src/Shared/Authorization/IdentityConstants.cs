﻿namespace FSH.Starter.Shared.Authorization;
public static class IdentityConstants
{
    public const int PasswordLength = 6;
    public const string SchemaName = "identity";
}
