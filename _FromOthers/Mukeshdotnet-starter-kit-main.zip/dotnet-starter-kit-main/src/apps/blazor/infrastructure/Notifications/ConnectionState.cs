﻿namespace FSH.Starter.Blazor.Infrastructure.Notifications;

public enum ConnectionState
{
    Connected,
    Connecting,
    Disconnected
}