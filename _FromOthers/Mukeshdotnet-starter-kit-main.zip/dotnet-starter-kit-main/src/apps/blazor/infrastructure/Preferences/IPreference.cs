﻿namespace FSH.Starter.Blazor.Infrastructure.Preferences;

public interface IPreference
{

}