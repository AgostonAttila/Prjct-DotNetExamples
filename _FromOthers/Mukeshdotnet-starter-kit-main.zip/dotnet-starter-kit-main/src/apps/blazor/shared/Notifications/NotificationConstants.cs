﻿namespace FSH.Starter.Blazor.Shared.Notifications;

public static class NotificationConstants
{
    public const string NotificationFromServer = nameof(NotificationFromServer);
}