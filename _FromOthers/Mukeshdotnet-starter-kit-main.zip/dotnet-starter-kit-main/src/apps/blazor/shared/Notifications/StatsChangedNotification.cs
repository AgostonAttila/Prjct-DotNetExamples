namespace FSH.Starter.Blazor.Shared.Notifications;

public class StatsChangedNotification : INotificationMessage
{
}