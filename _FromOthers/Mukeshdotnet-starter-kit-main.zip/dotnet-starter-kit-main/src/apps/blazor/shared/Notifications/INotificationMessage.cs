﻿namespace FSH.Starter.Blazor.Shared.Notifications;

public interface INotificationMessage
{
}