﻿namespace DockerEssentials.Models;

public record ProductCreationDto(string Name, string Description, decimal Price);
