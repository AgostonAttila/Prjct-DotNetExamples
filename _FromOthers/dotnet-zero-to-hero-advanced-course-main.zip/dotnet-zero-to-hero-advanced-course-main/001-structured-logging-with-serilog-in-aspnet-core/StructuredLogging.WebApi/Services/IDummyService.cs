﻿namespace StructuredLogging.WebApi.Services;

public interface IDummyService
{
    void DoSomething();
}
