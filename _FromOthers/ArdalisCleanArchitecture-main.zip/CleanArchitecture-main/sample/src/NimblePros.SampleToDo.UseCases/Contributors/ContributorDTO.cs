﻿namespace NimblePros.SampleToDo.UseCases.Contributors;
public record ContributorDTO(int Id, string Name);
