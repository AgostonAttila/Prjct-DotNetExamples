﻿namespace NimblePros.SampleToDo.Web.Projects;
public record ToDoItemRecord(int Id, string Title, string Description, bool IsDone, int? ContributorId);
