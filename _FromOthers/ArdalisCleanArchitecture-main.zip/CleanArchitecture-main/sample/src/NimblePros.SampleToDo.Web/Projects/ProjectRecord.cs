﻿namespace NimblePros.SampleToDo.Web.Projects;

public record ProjectRecord(int Id, string Name);
