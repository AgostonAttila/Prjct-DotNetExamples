﻿namespace NimblePros.SampleToDo.Web.Contributors;

public record ContributorRecord(int Id, string Name);
