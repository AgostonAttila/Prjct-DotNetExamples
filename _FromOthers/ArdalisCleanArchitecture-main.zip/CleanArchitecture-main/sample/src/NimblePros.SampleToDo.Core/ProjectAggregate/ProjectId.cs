﻿using Vogen;
namespace NimblePros.SampleToDo.Core.ProjectAggregate;

[ValueObject<int>]
public partial struct ProjectId;
