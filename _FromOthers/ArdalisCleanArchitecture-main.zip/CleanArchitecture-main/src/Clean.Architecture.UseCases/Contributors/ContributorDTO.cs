﻿namespace Clean.Architecture.UseCases.Contributors;
public record ContributorDTO(int Id, string Name, string? PhoneNumber);
