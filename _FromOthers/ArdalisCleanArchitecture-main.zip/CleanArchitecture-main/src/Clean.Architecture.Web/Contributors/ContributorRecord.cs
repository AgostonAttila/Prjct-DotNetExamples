﻿namespace Clean.Architecture.Web.Contributors;

public record ContributorRecord(int Id, string Name, string? PhoneNumber);
