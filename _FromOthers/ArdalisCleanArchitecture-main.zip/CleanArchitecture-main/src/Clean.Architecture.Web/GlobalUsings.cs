﻿global using FastEndpoints;
global using FastEndpoints.Swagger;
global using MediatR;
global using Serilog;
global using Serilog.Extensions.Logging;
global using Ardalis.Result;
