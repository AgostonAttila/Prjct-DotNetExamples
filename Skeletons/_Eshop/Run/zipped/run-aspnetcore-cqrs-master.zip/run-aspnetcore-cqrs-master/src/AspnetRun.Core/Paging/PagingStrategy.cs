﻿namespace AspnetRun.Core.Paging
{
    public enum PagingStrategy
    {
        WithCount = 0,
        NoCount = 1
    }
}
