﻿namespace AspnetRun.Api.Requests
{
    public class GetProductByIdRequest
    {
        public int Id { get; set; }
    }
}
