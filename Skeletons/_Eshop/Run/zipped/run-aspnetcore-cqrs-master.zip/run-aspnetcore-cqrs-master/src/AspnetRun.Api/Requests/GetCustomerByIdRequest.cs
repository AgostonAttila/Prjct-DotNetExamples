﻿namespace AspnetRun.Api.Requests
{
    public class GetCustomerByIdRequest
    {
        public int Id { get; set; }
    }
}
