﻿using AspnetRun.Core.Paging;

namespace AspnetRun.Api.Requests
{
    public class SearchPageRequest
    {
        public PageSearchArgs Args { get; set; }
    }
}
