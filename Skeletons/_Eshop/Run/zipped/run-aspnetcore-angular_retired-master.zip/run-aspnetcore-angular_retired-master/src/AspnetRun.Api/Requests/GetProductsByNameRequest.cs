﻿namespace AspnetRun.Api.Requests
{
    public class GetProductsByNameRequest
    {
        public string Name { get; set; }
    }
}
