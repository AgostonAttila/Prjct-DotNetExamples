﻿namespace AspnetRun.Api.Requests
{
    public class GetProductsByCategoryIdRequest
    {
        public int CategoryId { get; set; }
    }
}
