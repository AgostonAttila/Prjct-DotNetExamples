﻿namespace AspnetRun.Application.Models.Base
{
    public class EnumModel
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
