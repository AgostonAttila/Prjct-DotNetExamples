﻿namespace AspnetRun.Core.Configuration
{
    public class AspnetRunSettings
    {
        public string ConnectionString { get; set; }
    }
}
