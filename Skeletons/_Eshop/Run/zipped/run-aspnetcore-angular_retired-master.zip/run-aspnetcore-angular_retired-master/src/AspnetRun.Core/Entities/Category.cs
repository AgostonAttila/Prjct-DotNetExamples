﻿using AspnetRun.Core.Entities.Base;

namespace AspnetRun.Core.Entities
{
    public class Category : Entity
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
